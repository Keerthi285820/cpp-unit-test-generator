// ../tests/test_calculator.cpp
#include <gtest/gtest.h>
#include "calculator.h"

TEST(CalculatorTest, AddTwoPositiveNumbers) {
    Calculator calculator;
    EXPECT_EQ(4, calculator.add(2, 2));
}

TEST(CalculatorTest, SubtractTwoPositiveNumbers) {
    Calculator calculator;
    EXPECT_EQ(0, calculator.subtract(2, 2));
}

TEST(CalculatorTest, MultiplyTwoPositiveNumbers) {
    Calculator calculator;
    EXPECT_EQ(4, calculator.multiply(2, 2));
}

TEST(CalculatorTest, DivideTwoPositiveNumbers) {
    Calculator calculator;
    EXPECT_EQ(1, calculator.divide(2, 2));
}

TEST(CalculatorTest, AddOneZeroNumber) {
    Calculator calculator;
    EXPECT_EQ(2, calculator.add(0, 2));
}

TEST(CalculatorTest, SubtractOneZeroNumber) {
    Calculator calculator;
    EXPECT_EQ(2, calculator.subtract(2, 0));
}

TEST(CalculatorTest, DivideByZero) {
    Calculator calculator;
    ASSERT_THROW(calculator.divide(2, 0), std::invalid_argument);
}

int main(int argc, char **argv) {
    ::testing::InitGoogle(&argc, argv);
    return RUN_ALL_TESTS();
}

