from pathlib import Path
import subprocess

# File paths
cpp_file = Path("../cpp_src/calculator.cpp")
yaml_file = Path("../instructions/initial_prompt.yaml")
output_file = Path("../tests/test_calculator.cpp")

# Read contents
cpp_code = cpp_file.read_text()
yaml_prompt = yaml_file.read_text()

# Combine into full prompt
full_prompt = f"{yaml_prompt}\n\nHere is the C++ code:\n\n{cpp_code}"

# Run Ollama with llama3
print("Generating unit test using Ollama...")
result = subprocess.run(
    ["ollama", "run", "llama3", full_prompt],
    capture_output=True, text=True
)

# Save response to test file
output_file.write_text(result.stdout)
print(f"✅ Test file created at: {output_file}")
